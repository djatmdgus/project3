import pandas as pd
df = pd.read_csv('/Users/um_seun/project3/true_car_listings.csv')

df